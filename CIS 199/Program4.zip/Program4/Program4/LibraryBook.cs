﻿//Grading ID: C3839
//Program 4
//Due Date: 12/04/2018
//CIS-199-75
//This program displays some books in a library, then alters the check out status of some of the books using methods.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    using System;
    public class LibraryBook
    {
        
        private String title;//Title of book
        private String author;//Author of book
        private String publisher;//Publisher of book
        private int copyrightYear;//Book's copyright year
        private String callNumber;//Book's call number
        private bool checkoutStatus;//Book's checkout status

        // A 5-parameter constructor
        public LibraryBook(String bookTitle, String bookAuthor, String bookPublisher, int bookCopyrightYear, String bookCallNumber)
        {
            title = bookTitle;
            author = bookAuthor;
            publisher = bookPublisher;
            copyrightYear = bookCopyrightYear;
            callNumber = bookCallNumber;
            checkoutStatus = false;
        }

        
        public String Title
        {
            // Precondition:  None
            // Postcondition: A string is returned presenting the title
            get
            {
                return title;
            }
            // Precondition:  None
            // Postcondition: The title is set
            set
            {
                title = value;
            }
        }

        
        public String Author
        {
            // Precondition:  None
            // Postcondition: A string is returned presenting the author
            get
            {
                return author;
            }
            // Precondition:  None
            // Postcondition: The author is set
            set
            {
                author = value;
            }
        }

        
        public String Publisher
        {
            // Precondition:  None
            // Postcondition: A string is returned presenting the publisher
            get
            {
                return publisher;
            }
            // Precondition:  None
            // Postcondition: The publisher is set
            set
            {
                publisher = value;
            }
        }

        
        public int CopyrightYear
        {
            // Precondition:  None
            // Postcondition: the copyrightYear is returned
            get
            {
                return copyrightYear;
            }
            //Precondition: value >= 0
            //Postcondition: the copyrightYear is set to a specific value
            set
            {
                copyrightYear = value;
            }
        }

        // A String property named CallNumber with a get and set.
        public String CallNumber
        {
            // Precondition:  None
            // Postcondition: A string is returned presenting the callNumber
            get
            {
                return callNumber;
            }
            // Precondition:  None
            // Postcondition: The callNumber is set
            set
            {
                callNumber = value;
            }
        }

        // CheckOut() method will change the book's checked out status to reflect that the book has been checked out by a patron.
        public void CheckOut()
        {
            checkoutStatus = !checkoutStatus;
        }

        // ReturnToShelf() method change the book's checked out status to reflect that the book has been returned by a patron and is no longer checked out.
        public void ReturnToShelf()
        {
            checkoutStatus = !checkoutStatus;
        }

        // IsCheckedOut() method return a true value when the book is currently checked out and a false value when the book is not out.
        public bool IsCheckedOut()
        {
            return checkoutStatus;
        }

        // ToString() method a formatted string that has the book's details.
        public override String ToString()
        {
            String result = "";

            result += "Title: " + title + Environment.NewLine;
            result += "Author: " + author + Environment.NewLine;
            result += "Publisher: " + publisher + Environment.NewLine;
            result += "Copyright Year: " + copyrightYear + Environment.NewLine;
            result += "Call Number: " + callNumber + Environment.NewLine;
            result += "Checkout Status: " + checkoutStatus + Environment.NewLine;

            return result;
        }
    }
} 

    
