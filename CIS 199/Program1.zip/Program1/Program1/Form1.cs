﻿//Grading ID: C3839
//Program Number: 1
//Due Date: September 25th, 2018
//Course Section: CIS-199-75
//This program takes user input to determine the exact number of gallons of paint to buy

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Event for hitting the calculate button
        private void calcBtn_Click(object sender, EventArgs e)
        {
            const int doorSqft = 20;//Constant for square feet of doors
            const int windowSqft = 15;//Constant for square feet of windows
            const int paintSqft = 385;//Constant for square feet of of coverage per can of paint
            double length;//length of all walls
            double height;//height of walls
            int coats;//number of coats of paint needed
            int windows;//number of windows
            int doors;//number of doors
            double minGallons;//exact amount of paint needed
            int gallonsTobuy;//amount of paint needed rounded up to the nearest gallon
            

            length = Double.Parse(lengthTextbox.Text);//used to convert user input from text to numbers 
            height = Double.Parse(heightTextbox.Text);//used to convert user input from text to numbers 
            coats = int.Parse(coatsTextbox.Text); //used to convert user input from text to numbers 
            windows = int.Parse(windowsTextbox.Text) * windowSqft;//used to convert user input from text to numbers and multiply by square foot per window
            doors = int.Parse(doorsTextbox.Text) * doorSqft;//used to convert user input from text to numbers and multiply by square foot per door

            minGallons = (((length * height) - windows - doors) * coats) / paintSqft;//calculation to determine exact number of gallons of paint to buy
            gallonsTobuy = (int)Math.Ceiling(minGallons);//caluclation to determine whole number of gallons of paint to buy
            minTextbox.Text = $"{minGallons:F1}";//output for minimum amount of paint to buy
            totalTextbox.Text = $"{gallonsTobuy:F0}";//output for total amount of paint to buy




        }
    }
}
