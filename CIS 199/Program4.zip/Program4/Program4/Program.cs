﻿//Grading ID: C3839
//Program 4
//Due Date: 12/04/2018
//CIS-199-75
//This program displays some books in a library, then alters the check out status of some of the books using methods.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class Program
    {
        static void Main(string[] args)
        {
            //5 LibraryBook objects 
            LibraryBook book1 = new LibraryBook("Harry Potter", "J.K Rowling", "Bloomsbury Publishing", 1997, "12345");
            LibraryBook book2 = new LibraryBook("The Kite Runner", "Khaled Hosseini", "Riverhead Books", 2003, "24681");
            LibraryBook book3 = new LibraryBook("The Hobbit", "J.R.R Tolkien", "Allen and Unwin", 1937, "13579");
            LibraryBook book4 = new LibraryBook("American Psycho", "Bret Easton Ellis", "Vintage Books", 1991, "67891");
            LibraryBook book5 = new LibraryBook("God Hates Us All", "Hank Moody", "Jonathen Grotenstein", 2009, "34567");

            // Array of books
            LibraryBook[] books = { book1, book2, book3, book4, book5 };

            // printing original book data to the console
            Console.WriteLine("Books in library...");
            printBooks(books);
            
            //Checking out books 2,3, and 4
            book2.CheckOut();
            book3.CheckOut();
            book4.CheckOut();
            

            // Printing new data to the console
            Console.WriteLine("After updating...");
            printBooks(books);

            // returning checked out books
            book1.CheckOut();
            book2.CheckOut();
            book3.CheckOut();
            book4.CheckOut();
            book5.CheckOut();

            // Printing final data to the console
            Console.WriteLine("After updating again...");
            printBooks(books);

            Console.ReadKey();
        }

        // method for printing books
        public static void printBooks(LibraryBook[] books)
        {
            for (int i = 0; i < books.Length; i++)
            {
                Console.WriteLine("Book #" + (i + 1));
                Console.WriteLine(books[i]);
            }
        }
    } 
}

